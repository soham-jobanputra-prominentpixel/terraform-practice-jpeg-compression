import json
import urllib.parse
import boto3
from PIL import Image
import io
import os
import traceback

s3 = boto3.client("s3")

def lambda_handler(event, context):
    try:
        print("==== LAMBDA INVOKED ====")
        print("Full event:", json.dumps(event))

        # 1. Extract bucket + key
        record = event['Records'][0]
        bucket_name = record['s3']['bucket']['name']
        object_key = urllib.parse.unquote_plus(
            record['s3']['object']['key']
        )

        print(f"[INFO] Source Bucket: {bucket_name}")
        print(f"[INFO] Object Key: {object_key}")

        # Prevent infinite loop
        if object_key.lower().endswith(".webp"):
            print("[SKIP] File already WEBP. Exiting.")
            return

        # 2. Get object
        print("[STEP] Fetching object from S3...")
        response = s3.get_object(
            Bucket=bucket_name,
            Key=object_key
        )

        print("[DEBUG] S3 get_object response metadata:", response.get("ResponseMetadata"))

        image_bytes = response['Body'].read()
        print(f"[INFO] Downloaded bytes: {len(image_bytes)}")

        if len(image_bytes) == 0:
            raise ValueError("Downloaded file is empty!")

        # 3. Load image
        print("[STEP] Opening image with Pillow...")
        image = Image.open(io.BytesIO(image_bytes))

        print(f"[INFO] Image format: {image.format}")
        print(f"[INFO] Image mode: {image.mode}")
        print(f"[INFO] Image size: {image.size}")

        # Convert if needed
        if image.mode in ("RGBA", "P"):
            print("[STEP] Converting image to RGB...")
            image = image.convert("RGB")

        # 4. Convert to WEBP
        print("[STEP] Converting to WEBP...")
        buffer = io.BytesIO()
        image.save(buffer, format="WEBP", quality=20, alpha_quality=0, method=6)
        buffer.seek(0)

        output_size = buffer.getbuffer().nbytes
        print(f"[INFO] WEBP size: {output_size} bytes")

        if output_size == 0:
            raise ValueError("Converted WEBP is empty!")

        # 5. New key
        base_name = os.path.splitext(object_key)[0]
        new_key = f"{base_name}.webp"

        print(f"[INFO] Destination Key: {new_key}")

        # 6. Upload
        print("[STEP] Uploading to destination bucket...")
        destination_bucket = "image-processor-destination-501046919017-us-east-1-an"
        print(f"[INFO] Destination Bucket: {destination_bucket}")

        response = s3.put_object(
            Bucket=destination_bucket,
            Key=new_key,
            Body=buffer.getvalue(),  # <-- important fix
            ContentType="image/webp"
        )

        print("[SUCCESS] Upload response:", response)

        # Verify upload (critical debug)
        print("[STEP] Verifying uploaded object...")
        head = s3.head_object(
            Bucket=destination_bucket,
            Key=new_key
        )

        print("[SUCCESS] Verified object exists. Metadata:", head)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Conversion successful",
                "output_key": new_key
            })
        }

    except Exception as e:
        print("[ERROR] Exception occurred!")
        print(str(e))
        print(traceback.format_exc())
        raise
